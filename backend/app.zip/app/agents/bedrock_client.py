"""
app/agents/bedrock_client.py  — FIXED VERSION
Key fixes:
1. Falls back to direct Claude model if Agent ID not configured
2. Better error messages with actual exception details logged
3. Handles ThrottlingException, AccessDeniedException, ValidationException
4. Test mode: if BEDROCK_AGENT_ID is empty, uses direct model invocation
"""
import asyncio
import json
import time
import uuid
from collections.abc import AsyncGenerator

import boto3
import structlog
from botocore.config import Config
from botocore.exceptions import ClientError, NoCredentialsError

from app.core.config import settings
from app.core.metrics import (
    bedrock_requests_total,
    bedrock_response_latency_ms,
    bedrock_tokens_used_total,
    bedrock_errors_total,
)

log = structlog.get_logger()


class BedrockAgentClient:

    def __init__(self):
        boto_config = Config(
            region_name=settings.AWS_REGION,
            retries={"max_attempts": 2, "mode": "adaptive"},
            connect_timeout=10,
            read_timeout=120,
        )

        credentials = {}
        if settings.AWS_ACCESS_KEY_ID and settings.AWS_ACCESS_KEY_ID.get_secret_value():
            credentials["aws_access_key_id"] = settings.AWS_ACCESS_KEY_ID.get_secret_value()
            credentials["aws_secret_access_key"] = settings.AWS_SECRET_ACCESS_KEY.get_secret_value()

        try:
            self._runtime = boto3.client("bedrock-agent-runtime", config=boto_config, **credentials)
            self._bedrock = boto3.client("bedrock-runtime", config=boto_config, **credentials)
            log.info("bedrock.client_initialized", region=settings.AWS_REGION)
        except Exception as e:
            log.error("bedrock.client_init_failed", error=str(e))
            self._runtime = None
            self._bedrock = None

    async def invoke_agent_streaming(
        self,
        user_message: str,
        session_id: str,
        *,
        agent_id: str | None = None,
        agent_alias_id: str | None = None,
        knowledge_base_id: str | None = None,
    ) -> AsyncGenerator[dict, None]:
        """
        Stream response from Bedrock Agent.
        Falls back to direct model call if Agent ID is not configured.
        """
        start_time = time.time()
        status = "success"
        error_code = None

        # If agent not configured, use direct model (good for dev/testing)
        effective_agent_id = agent_id if agent_id is not None else settings.BEDROCK_AGENT_ID
        effective_agent_alias_id = (
            agent_alias_id if agent_alias_id is not None else settings.BEDROCK_AGENT_ALIAS_ID
        )

        agent_configured = bool(
            effective_agent_id and
            effective_agent_id not in ("", "YOUR_AGENT_ID", "test")
        )

        if not agent_configured:
            log.warning("bedrock.agent_not_configured_using_direct_model")
            async for chunk in self._invoke_direct_streaming(user_message, start_time):
                yield chunk
            return

        loop = asyncio.get_event_loop()

        try:
            response = await loop.run_in_executor(
                    None,
                lambda: self._runtime.invoke_agent(
                    agentId=effective_agent_id,
                    agentAliasId=effective_agent_alias_id,
                    sessionId=session_id,
                    inputText=user_message,
                    enableTrace=False,
                    endSession=False,
                ),
            )

            full_text = ""
            tokens_used = 0

            for event in response.get("completion", []):
                if "chunk" in event:
                    chunk_bytes = event["chunk"].get("bytes", b"")
                    if chunk_bytes:
                        text = chunk_bytes.decode("utf-8")
                        full_text += text
                        yield {"type": "text", "content": text}

                elif "trace" in event:
                    trace = event["trace"]
                    if "orchestrationTrace" in trace:
                        orch = trace["orchestrationTrace"]
                        if "modelInvocationOutput" in orch:
                            usage = orch["modelInvocationOutput"].get("usage", {})
                            tokens_used = usage.get("inputTokens", 0) + usage.get("outputTokens", 0)

            # latency_ms = int((time.time() - start_time) * 1000)
            # yield {"type": "end", "metadata": {"tokens_used": tokens_used, "latency_ms": latency_ms, "model_id": settings.BEDROCK_MODEL_ID}}
            latency_ms = int((time.time() - start_time) * 1000)

            # Metrics
            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(status="success").inc()

            if tokens_used:
                bedrock_tokens_used_total.labels(direction="output").inc(tokens_used)

            yield {
                "type": "end",
                "metadata": {
                    "tokens_used": tokens_used,
                    "latency_ms": latency_ms,
                    "model_id": settings.BEDROCK_MODEL_ID,
                },
            }

        except NoCredentialsError:
            log.error("bedrock.no_credentials")
            yield {"type": "error", "content": "AWS credentials not configured. Please check AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in your .env file."}

        except ClientError as e:
            code = e.response["Error"]["Code"]
            msg = e.response["Error"]["Message"]
            # log.error("bedrock.client_error", code=code, message=msg)
            latency_ms = int((time.time() - start_time) * 1000)

            # Metrics
            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(
                status="throttled" if code == "ThrottlingException" else "error"
            ).inc()
            bedrock_errors_total.labels(error_code=code).inc()

            log.error("bedrock.client_error", code=code, message=msg)

            if code == "AccessDeniedException":
                yield {"type": "error", "content": f"AWS access denied. Check your IAM permissions for Bedrock. ({msg})"}
            elif code == "ThrottlingException":
                yield {"type": "error", "content": "Bedrock is throttling requests. Please try again in a moment."}
            elif code == "ValidationException":
                yield {"type": "error", "content": f"Invalid Bedrock configuration. Check your BEDROCK_AGENT_ID and BEDROCK_AGENT_ALIAS_ID. ({msg})"}
            elif code == "ResourceNotFoundException":
                yield {"type": "error", "content": f"Bedrock resource not found. Check your Agent ID, Alias ID, and Knowledge Base ID. ({msg})"}
            else:
                yield {"type": "error", "content": f"Bedrock error ({code}): {msg}"}

        except Exception as e:
            latency_ms = int((time.time() - start_time) * 1000)

            # Metrics
            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(status="error").inc()
            bedrock_errors_total.labels(error_code=type(e).__name__).inc()

            log.error("bedrock.unexpected_error", error=str(e), exc_info=True)
            # yield {"type": "error", "content": f"Unexpected error: {str(e)[:200]}"}

    async def _invoke_direct_streaming(
        self,
        user_message: str,
        start_time: float,
    ) -> AsyncGenerator[dict, None]:
        """Direct model call — used when Agent is not configured."""
        loop = asyncio.get_event_loop()

        system_prompt = (
            "You are TissaTech Assistant, a helpful AI for TissaTech company. "
            "Answer questions about software development, technology, and TissaTech services. "
            "Be concise, helpful, and professional."
        )

        start_time = start_time

        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": settings.BEDROCK_MAX_TOKENS,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_message}],
        }

        try:
            response = await loop.run_in_executor(
                None,
                lambda: self._bedrock.invoke_model_with_response_stream(
                    modelId=settings.BEDROCK_MODEL_ID,
                    body=json.dumps(body),
                    contentType="application/json",
                    accept="application/json",
                ),
            )

            tokens_used = 0
            for event in response.get("body", []):
                chunk = json.loads(event["chunk"]["bytes"])
                if chunk["type"] == "content_block_delta":
                    text = chunk["delta"].get("text", "")
                    if text:
                        yield {"type": "text", "content": text}
                elif chunk["type"] == "message_delta":
                    tokens_used = chunk.get("usage", {}).get("output_tokens", 0)

            # latency_ms = int((time.time() - start_time) * 1000)
            # yield {"type": "end", "metadata": {"tokens_used": tokens_used, "latency_ms": latency_ms, "model_id": settings.BEDROCK_MODEL_ID}}
            latency_ms = int((time.time() - start_time) * 1000)

            # Metrics
            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(status="success").inc()

            if tokens_used:
                bedrock_tokens_used_total.labels(direction="output").inc(tokens_used)

            yield {
                "type": "end",
                "metadata": {
                    "tokens_used": tokens_used,
                    "latency_ms": latency_ms,
                    "model_id": settings.BEDROCK_MODEL_ID,
                },
            }

        except NoCredentialsError:
            yield {"type": "error", "content": "AWS credentials not configured. Add AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY to your .env file."}
        except ClientError as e:
            code = e.response["Error"]["Code"]
            msg = e.response["Error"]["Message"]

            latency_ms = int((time.time() - start_time) * 1000)

            # Metrics
            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(
                status="throttled" if code == "ThrottlingException" else "error"
            ).inc()
            bedrock_errors_total.labels(error_code=code).inc()

            log.error("bedrock.direct_error", code=code, message=msg)
            yield {"type": "error", "content": f"Bedrock error ({code}): {msg}"}
        except Exception as e:
            latency_ms = int((time.time() - start_time) * 1000)

            bedrock_response_latency_ms.observe(latency_ms)
            bedrock_requests_total.labels(status="error").inc()
            bedrock_errors_total.labels(error_code=type(e).__name__).inc()

            log.error("bedrock.direct_unexpected", error=str(e), exc_info=True)
            # yield {"type": "error", "content": f"Error calling Bedrock: {str(e)[:200]}"}

    async def search_knowledge_base(
        self,
        query: str,
        num_results: int = 15,
        *,
        knowledge_base_id: str | None = None,
    ) -> list:
        effective_kb_id = (
            knowledge_base_id if knowledge_base_id is not None else settings.BEDROCK_KNOWLEDGE_BASE_ID
        )
        if not effective_kb_id or effective_kb_id in ("", "YOUR_KB_ID"):
            log.warning("bedrock.kb_not_configured")
            return []

        loop = asyncio.get_event_loop()
        try:
            response = await loop.run_in_executor(
                None,
                lambda: self._runtime.retrieve(
                    knowledgeBaseId=effective_kb_id,
                    retrievalQuery={"text": query},
                    retrievalConfiguration={"vectorSearchConfiguration": {"numberOfResults": num_results}},
                ),
            )
            return [
                {
                    "content": item["content"]["text"],
                    "score": item.get("score", 0.0),
                    "source": item.get("location", {}).get("s3Location", {}).get("uri", ""),
                }
                for item in response.get("retrievalResults", [])
            ]
        except Exception as e:
            log.error("bedrock.kb_search_error", error=str(e))
            return []


bedrock_client = BedrockAgentClient()
