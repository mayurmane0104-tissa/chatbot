"""
app/api/admin.py
Admin endpoints for conversation management, analytics, and knowledge base.
"""
import uuid
from datetime import datetime, timedelta, timezone

import structlog
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.auth import require_admin
from app.db.models import Conversation, Message, MessageFeedback, Document, DocumentStatus, FeedbackType
from app.db.session import get_db

log = structlog.get_logger()
router = APIRouter()


@router.get("/analytics/overview")
async def get_analytics(
    days: int = 30,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    since = datetime.now(timezone.utc) - timedelta(days=days)

    total_conversations = await db.scalar(
        select(func.count(Conversation.id)).where(
            Conversation.workspace_id == admin.workspace_id,
            Conversation.created_at >= since,
        )
    )

    total_messages = await db.scalar(
        select(func.count(Message.id)).join(Conversation).where(
            Conversation.workspace_id == admin.workspace_id,
            Message.created_at >= since,
        )
    )

    thumbs_up = await db.scalar(
        select(func.count(MessageFeedback.id)).join(Message).join(Conversation).where(
            Conversation.workspace_id == admin.workspace_id,
            MessageFeedback.feedback_type == FeedbackType.THUMBS_UP,
            MessageFeedback.created_at >= since,
        )
    )

    thumbs_down = await db.scalar(
        select(func.count(MessageFeedback.id)).join(Message).join(Conversation).where(
            Conversation.workspace_id == admin.workspace_id,
            MessageFeedback.feedback_type == FeedbackType.THUMBS_DOWN,
            MessageFeedback.created_at >= since,
        )
    )

    avg_latency = await db.scalar(
        select(func.avg(Message.latency_ms)).join(Conversation).where(
            Conversation.workspace_id == admin.workspace_id,
            Message.latency_ms.isnot(None),
            Message.created_at >= since,
        )
    )

    total_feedback = (thumbs_up or 0) + (thumbs_down or 0)
    satisfaction_rate = round((thumbs_up or 0) / total_feedback * 100, 1) if total_feedback > 0 else None

    return {
        "period_days": days,
        "total_conversations": total_conversations or 0,
        "total_messages": total_messages or 0,
        "satisfaction_rate": satisfaction_rate,
        "avg_latency_ms": round(avg_latency or 0),
        "thumbs_up": thumbs_up or 0,
        "thumbs_down": thumbs_down or 0,
    }


@router.get("/conversations")
async def admin_list_conversations(
    page: int = 1,
    page_size: int = 50,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    offset = (page - 1) * page_size
    result = await db.execute(
        select(Conversation)
        .where(Conversation.workspace_id == admin.workspace_id)
        .order_by(Conversation.updated_at.desc())
        .offset(offset)
        .limit(min(page_size, 100))
    )
    convs = result.scalars().all()
    return [
        {
            "id": str(c.id),
            "title": c.title,
            "status": c.status,
            "message_count": c.message_count,
            "channel": c.channel,
            "created_at": c.created_at.isoformat(),
        }
        for c in convs
    ]


@router.post("/documents")
async def upload_document(
    file: UploadFile = File(...),
    title: str = "",
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    """Upload a document to the knowledge base."""
    ALLOWED_MIME_TYPES = {"application/pdf", "text/plain", "text/markdown"}

    if file.content_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.content_type}")

    MAX_SIZE = 50 * 1024 * 1024  # 50MB
    content = await file.read()
    if len(content) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large (max 50MB)")

    doc = Document(
        workspace_id=admin.workspace_id,
        title=title or file.filename or "Untitled",
        file_name=file.filename,
        file_size=len(content),
        mime_type=file.content_type,
        status=DocumentStatus.PENDING,
    )
    db.add(doc)
    await db.flush()

    # Queue async processing
    from app.workers.tasks import process_document
    process_document.delay(str(doc.id), content.decode("utf-8", errors="ignore"))

    log.info("document.uploaded", doc_id=str(doc.id), title=doc.title)
    return {"id": str(doc.id), "title": doc.title, "status": doc.status}


@router.get("/documents")
async def list_documents(
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Document)
        .where(Document.workspace_id == admin.workspace_id)
        .order_by(Document.created_at.desc())
    )
    docs = result.scalars().all()
    return [
        {
            "id": str(d.id),
            "title": d.title,
            "file_name": d.file_name,
            "file_size": d.file_size,
            "status": d.status,
            "chunk_count": d.chunk_count,
            "created_at": d.created_at.isoformat(),
        }
        for d in docs
    ]


@router.delete("/documents/{document_id}")
async def delete_document(
    document_id: uuid.UUID,
    admin=Depends(require_admin),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Document).where(
            Document.id == document_id,
            Document.workspace_id == admin.workspace_id,
        )
    )
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    await db.delete(doc)
    return {"deleted": True}
