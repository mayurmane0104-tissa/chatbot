from functools import lru_cache
import json
from typing import Literal, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator, SecretStr


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    APP_NAME: str = "TissaTech AI Agent"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: Literal["development", "staging", "production"] = "development"
    DEBUG: bool = False
    SECRET_KEY: SecretStr = SecretStr("dev-secret-key-change-in-production-32chars")

    API_PREFIX: str = "/api/v1"
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000", "*"]
    DOCS_URL: Optional[str] = "/docs"

    DATABASE_URL: str = "postgresql+asyncpg://tissatech:password@localhost:5432/tissatech"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 5
    DATABASE_POOL_TIMEOUT: int = 30

    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_TTL: int = 3600

    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    AWS_REGION: str = "us-east-1"
    AWS_ACCESS_KEY_ID: Optional[SecretStr] = None
    AWS_SECRET_ACCESS_KEY: Optional[SecretStr] = None
    BEDROCK_AGENT_ID: str = ""
    BEDROCK_AGENT_ALIAS_ID: str = "TSTALIASID"
    BEDROCK_MODEL_ID: str = "anthropic.claude-3-sonnet-20240229-v1:0"
    BEDROCK_KNOWLEDGE_BASE_ID: str = ""
    BEDROCK_MAX_TOKENS: int = 2048

    MCP_SERVER_NAME: str = "tissatech-mcp"
    MCP_HOST: str = "0.0.0.0"
    MCP_PORT: int = 8001

    RATE_LIMIT_REQUESTS: int = 60
    RATE_LIMIT_WINDOW: int = 60

    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    MAX_MESSAGE_LENGTH: int = 4096
    MAX_CONVERSATION_HISTORY: int = 20

    # @field_validator("ALLOWED_ORIGINS", mode="before")
    # @classmethod
    # def parse_origins(cls, v):
    #     if isinstance(v, str):
    #         try:
    #             return json.loads(v)  # handles ["*"]
    #         except:
    #             return [o.strip() for o in v.split(",")]  # fallback
    #     return v

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
