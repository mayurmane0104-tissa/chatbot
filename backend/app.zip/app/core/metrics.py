"""
app/core/metrics.py
Custom Prometheus metrics for TissaTech AI Agent.
Add these to your main.py to track Bedrock, chat, and business metrics.
"""
from prometheus_client import Counter, Histogram, Gauge, Summary

# ── HTTP / API ─────────────────────────────────────────────────────────────
chat_messages_total = Counter(
    "tissatech_chat_messages_total",
    "Total chat messages sent",
    ["role"],  # user / assistant
)

chat_errors_total = Counter(
    "tissatech_chat_errors_total",
    "Total chat errors",
    ["error_type"],  # bedrock_error / db_error / injection_blocked
)

active_conversations = Gauge(
    "tissatech_active_conversations_total",
    "Number of active conversations in last 24h",
)

# ── Bedrock / AI ───────────────────────────────────────────────────────────
bedrock_requests_total = Counter(
    "bedrock_requests_total",
    "Total Bedrock API calls",
    ["status"],  # success / error / throttled
)

bedrock_response_latency_ms = Histogram(
    "bedrock_response_latency_ms",
    "Bedrock response latency in milliseconds",
    buckets=[500, 1000, 2000, 3000, 5000, 8000, 10000, 15000, 30000],
)

bedrock_tokens_used_total = Counter(
    "bedrock_tokens_used_total",
    "Total tokens consumed from Bedrock",
    ["direction"],  # input / output
)

bedrock_errors_total = Counter(
    "bedrock_errors_total",
    "Total Bedrock errors by type",
    ["error_code"],  # ThrottlingException / AccessDeniedException / etc.
)

# ── Knowledge Base ─────────────────────────────────────────────────────────
kb_search_total = Counter(
    "kb_search_total",
    "Total knowledge base searches",
    ["result"],  # found / not_found
)

kb_documents_total = Gauge(
    "kb_documents_total",
    "Total indexed documents in knowledge base",
)

# ── User / Session ─────────────────────────────────────────────────────────
user_sessions_total = Counter(
    "user_sessions_total",
    "Total user sessions started",
)

user_feedback_total = Counter(
    "user_feedback_total",
    "User message feedback",
    ["type"],  # thumbs_up / thumbs_down
)

# ── Usage example in bedrock_client.py ────────────────────────────────────
# from app.core.metrics import bedrock_requests_total, bedrock_response_latency_ms
#
# with bedrock_response_latency_ms.time():
#     response = await bedrock_client.invoke_agent_streaming(...)
#
# bedrock_requests_total.labels(status="success").inc()
