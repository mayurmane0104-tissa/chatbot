"""
app/workers/tasks.py
Celery background tasks for document processing, embeddings, cleanup.
"""
import asyncio
import uuid

import structlog
from celery import Celery

from app.core.config import settings

log = structlog.get_logger()

celery_app = Celery(
    "tissatech",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_soft_time_limit=300,  # 5 min soft limit
    task_time_limit=600,       # 10 min hard limit
    worker_max_tasks_per_child=100,  # prevent memory leaks
)


@celery_app.task(bind=True, max_retries=3)
def process_document(self, document_id: str, content: str):
    """
    Async document ingestion:
    1. Clean and chunk text
    2. Generate embeddings via Amazon Titan
    3. Store in pgvector
    4. Sync to Bedrock Knowledge Base S3 bucket
    """
    try:
        asyncio.run(_process_document_async(document_id, content))
    except Exception as exc:
        log.error("task.process_document_failed", doc_id=document_id, error=str(exc))
        raise self.retry(exc=exc, countdown=60)


async def _process_document_async(document_id: str, content: str):
    from app.db.session import AsyncSessionLocal
    from app.db.models import Document, DocumentChunk, DocumentStatus

    # Simple chunking: 500 token chunks with 50 token overlap
    chunks = _chunk_text(content, chunk_size=1500, overlap=200)

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            __import__("sqlalchemy", fromlist=["select"]).select(Document).where(
                Document.id == uuid.UUID(document_id)
            )
        )
        doc = result.scalar_one_or_none()
        if not doc:
            return

        doc.status = DocumentStatus.PROCESSING
        await db.flush()

        # Generate embeddings for each chunk
        for i, chunk_text in enumerate(chunks):
            embedding = await _get_embedding(chunk_text)
            chunk = DocumentChunk(
                document_id=doc.id,
                chunk_index=i,
                content=chunk_text,
                embedding=embedding,
                token_count=len(chunk_text.split()),
            )
            db.add(chunk)

        doc.status = DocumentStatus.INDEXED
        doc.chunk_count = len(chunks)
        await db.commit()

        log.info("document.indexed", doc_id=document_id, chunks=len(chunks))


def _chunk_text(text: str, chunk_size: int = 1500, overlap: int = 200) -> list[str]:
    """Split text into overlapping chunks."""
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = min(start + chunk_size, len(words))
        chunk = " ".join(words[start:end])
        chunks.append(chunk)
        if end >= len(words):
            break
        start += chunk_size - overlap
    return chunks


async def _get_embedding(text: str) -> list[float]:
    """Get embedding vector from Amazon Titan."""
    import boto3
    import json

    client = boto3.client("bedrock-runtime", region_name=settings.AWS_REGION)
    response = client.invoke_model(
        modelId="amazon.titan-embed-text-v1",
        body=json.dumps({"inputText": text[:8000]}),  # Titan max input
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    return result["embedding"]


@celery_app.task
def cleanup_expired_sessions():
    """Periodic task: remove expired sessions and refresh tokens."""
    asyncio.run(_cleanup_async())


async def _cleanup_async():
    from datetime import datetime, timezone
    from sqlalchemy import delete
    from app.db.session import AsyncSessionLocal
    from app.db.models import Session, RefreshToken

    async with AsyncSessionLocal() as db:
        now = datetime.now(timezone.utc)
        await db.execute(delete(Session).where(Session.expires_at < now))
        await db.execute(delete(RefreshToken).where(RefreshToken.expires_at < now))
        await db.commit()
        log.info("cleanup.completed")
