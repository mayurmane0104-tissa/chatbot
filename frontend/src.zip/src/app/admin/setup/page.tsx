'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Bot, Globe, DatabaseZap, Palette, Code2, ArrowRight,
  CheckCircle2, Pipette, Layout, MessageSquare,
  Trash2, Copy, Plus, X, Send, AlertCircle, Loader2
} from 'lucide-react';
import { adminApi, widgetApi } from '@/lib/api';

const AVATAR_IMAGES = [
  'https://cdn-icons-png.flaticon.com/512/4712/4712109.png',
  'https://cdn-icons-png.flaticon.com/512/204/204328.png',
  'https://cdn-icons-png.flaticon.com/512/194/194938.png',
  'https://cdn-icons-png.flaticon.com/512/2919/2919572.png',
  'https://cdn-icons-png.flaticon.com/512/3211/3211186.png',
];

const steps = [
  { id: 1, name: 'Train', icon: DatabaseZap },
  { id: 2, name: 'Customize', icon: Palette },
  { id: 3, name: 'Get Your Code', icon: Code2 },
];

function ChevronDown({ className = '' }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className={`w-5 h-5 ${className}`}>
      <path strokeLinecap="round" strokeLinejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
    </svg>
  );
}

export default function SetupWizard() {
  const [currentStep, setCurrentStep] = useState(1);

  // Step 1 — Train
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [isTraining, setIsTraining] = useState(false);
  const [isTrained, setIsTrained] = useState(false);
  const [trainError, setTrainError] = useState('');
  const [trainedUrl, setTrainedUrl] = useState('');
  const [crawlTaskId, setCrawlTaskId] = useState('');

  // Step 2 — Customize
  const [botName, setBotName] = useState('Tissa');
  const [welcomeMsg, setWelcomeMsg] = useState("Hi there! 👋 I'm Tissa. I'm here to help with information on TissaTech's services. How can I assist you today?");
  const [primaryColor, setPrimaryColor] = useState('#E65C5C');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_IMAGES[4]);
  const [activeAccordion, setActiveAccordion] = useState<string | null>('avatar');
  const [showEmailField, setShowEmailField] = useState(true);
  const [showNameField, setShowNameField] = useState(true);
  const [isSavingConfig, setIsSavingConfig] = useState(false);
  const [configSaved, setConfigSaved] = useState(false);

  // Step 3 — Deploy
  const [copySuccess, setCopySuccess] = useState(false);
  const [widgetApiKey, setWidgetApiKey] = useState<string>('');
  const [isGeneratingApiKey, setIsGeneratingApiKey] = useState(false);

  // Auto-generate a fresh widget API key when entering the deploy step.
  // This raw key is used as `data-bot-id` in the embed snippet and must be sent
  // back as `X-API-Key` by the widget frontend.
  useEffect(() => {
    if (currentStep !== 3) return;
    if (widgetApiKey) return;
    let cancelled = false;
    setIsGeneratingApiKey(true);
    widgetApi.createApiKey()
      .then((res) => {
        if (!cancelled) setWidgetApiKey(res.api_key);
      })
      .catch(() => {
        // If key generation fails, we still render the page; user can retry by refreshing.
      })
      .finally(() => {
        if (!cancelled) setIsGeneratingApiKey(false);
      });
    return () => {
      cancelled = true;
    };
  }, [currentStep, widgetApiKey]);

  const handleTrain = async () => {
    if (!websiteUrl.trim()) return;
    setIsTraining(true);
    setTrainError('');
    try {
      const url = websiteUrl.startsWith('http') ? websiteUrl : `https://${websiteUrl}`;
      const result = await adminApi.triggerCrawl(url, 100) as any;
      setCrawlTaskId(result.task_id ?? '');
      setTrainedUrl(websiteUrl);
      setIsTrained(true);
      setTimeout(() => setCurrentStep(2), 800);
    } catch (e: any) {
      setTrainError(e.detail ?? 'Crawl failed. Check your backend is running.');
    } finally {
      setIsTraining(false);
    }
  };

  const handleSaveConfig = async () => {
    setIsSavingConfig(true);
    try {
      await widgetApi.saveConfig({
        bot_name: botName,
        greeting_message: welcomeMsg,
        primary_color: primaryColor,
        placeholder_text: 'Type a message...',
        position: 'bottom-right',
      });
      setConfigSaved(true);
      setTimeout(() => setCurrentStep(3), 600);
    } catch (e: any) {
      // If endpoint doesn't exist yet, still advance
      setConfigSaved(true);
      setTimeout(() => setCurrentStep(3), 600);
    } finally {
      setIsSavingConfig(false);
    }
  };

  const copyCode = () => {
    if (!widgetApiKey) return;
    const code = `<script src="${window.location.origin}/embed.js" data-bot-id="${widgetApiKey}" data-base-url="${window.location.origin}" defer></script>`;
    navigator.clipboard.writeText(code);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2500);
  };

  const AccordionItem = ({ id, title, icon: Icon, children }: any) => {
    const isOpen = activeAccordion === id;
    return (
      <div className="bg-white border border-slate-100 rounded-2xl shadow-sm overflow-hidden mb-3">
        <button onClick={() => setActiveAccordion(isOpen ? null : id)}
          className="w-full flex items-center justify-between p-5 text-left focus:outline-none">
          <div className="flex items-center gap-3.5 text-slate-700">
            <Icon size={20} className="text-slate-400" />
            <span className="font-semibold text-base">{title}</span>
          </div>
          <ChevronDown className={`text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
        {isOpen && <div className="px-5 pb-5 pt-0 border-t border-slate-50">{children}</div>}
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      {/* Header */}
      <header className="bg-slate-950 text-white p-4 px-10 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2 font-black text-2xl tracking-tighter text-[#C9FA62]">
          <Bot size={28} /> BotOS
        </div>
        <div className="flex items-center gap-3">
          {steps.map((step, index) => {
            const isActive = currentStep === step.id;
            const isCompleted = currentStep > step.id;
            return (
              <div key={step.id} className="flex items-center gap-3">
                <div className={`flex items-center gap-2.5 px-5 py-2 rounded-full ${isActive ? 'bg-white text-slate-950 font-bold' : isCompleted ? 'bg-slate-800 text-green-400' : 'text-slate-500'}`}>
                  {isCompleted ? <CheckCircle2 size={16} /> : isActive ? <step.icon size={16} /> : <div className="w-4 h-4 rounded-full border border-current text-xs flex items-center justify-center font-bold">{step.id}</div>}
                  <span className="text-sm">{step.name}</span>
                </div>
                {index < steps.length - 1 && <div className={`w-8 h-px ${currentStep > step.id ? 'bg-green-400' : 'bg-slate-700'}`} />}
              </div>
            );
          })}
        </div>
        <button onClick={() => setCurrentStep((p) => Math.min(3, p + 1))}
          className="bg-[#C9FA62] text-slate-950 px-10 py-3 rounded-full font-extrabold text-sm hover:bg-[#b5e64a]">
          Next <ArrowRight size={18} className="inline ml-1" />
        </button>
      </header>

      <main className="flex-1 p-8 lg:p-12 relative flex flex-col items-center">

        {/* STEP 1: TRAIN */}
        {currentStep === 1 && (
          <div className="w-full max-w-5xl space-y-12">
            <div className="text-center max-w-3xl mx-auto space-y-4">
              <h1 className="text-5xl font-extrabold text-slate-950 tracking-tight">Setup your Knowledge Base</h1>
              <p className="text-lg text-slate-600 leading-relaxed">
                Provide your website URL and our AI will crawl your pages to understand your business, products, and FAQs.
              </p>
            </div>

            <div className="bg-white p-10 rounded-3xl border border-slate-100 shadow-xl">
              <div className="flex gap-4">
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleTrain()}
                  placeholder="www.tissatech.com"
                  className="flex-1 p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-slate-400 font-mono text-sm"
                />
                <button
                  onClick={handleTrain}
                  disabled={!websiteUrl || isTraining}
                  className="px-10 py-4 bg-slate-950 text-white font-bold rounded-xl hover:bg-black transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {isTraining ? <><Loader2 size={20} className="animate-spin" /> Crawling...</> : <><DatabaseZap size={20} /> Crawl Content</>}
                </button>
              </div>
              {trainError && (
                <div className="mt-4 flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-xl text-sm">
                  <AlertCircle size={16} /> {trainError}
                </div>
              )}
              {crawlTaskId && (
                <p className="mt-3 text-xs text-slate-400 font-mono">Task ID: {crawlTaskId} — Running in background</p>
              )}
            </div>

            {isTrained && (
              <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between max-w-3xl mx-auto">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400"><Globe size={24} /></div>
                  <div>
                    <p className="font-semibold text-slate-950">{trainedUrl}</p>
                    <p className="text-xs text-green-600 flex items-center gap-1.5 font-medium"><CheckCircle2 size={14} /> Crawl started — indexing in background</p>
                  </div>
                </div>
                <button onClick={() => { setIsTrained(false); setTrainedUrl(''); }} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-red-600 hover:bg-red-50">
                  <Trash2 size={18} />
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: CUSTOMIZE */}
        {currentStep === 2 && (
          <div className="w-full flex-1 flex flex-col">
            <div className="absolute inset-0 bg-slate-100 z-0 pt-[72px]">
              <div className="w-full h-full bg-gradient-to-br from-slate-200 to-slate-100 opacity-60" />
            </div>

            <div className="flex-1 flex relative z-10 gap-10">
              <div className="w-full max-w-sm p-4 pt-12">
                <div className="bg-white rounded-[2rem] p-5 shadow-2xl border border-slate-100/50">
                  <h3 className="text-xl font-bold text-slate-950 mb-6 p-1">Customization</h3>
                  <div className="space-y-1">
                    <AccordionItem id="avatar" title="Avatar" icon={MessageSquare}>
                      <div className="grid grid-cols-4 gap-3">
                        {AVATAR_IMAGES.map((img, i) => (
                          <button key={i} onClick={() => setSelectedAvatar(img)} className="relative group">
                            <img src={img} alt={`Avatar ${i}`} className={`w-14 h-14 rounded-full border-4 object-cover ${selectedAvatar === img ? 'border-red-400' : 'border-white'}`} />
                          </button>
                        ))}
                        <button className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center border-4 border-white text-slate-400 font-bold hover:bg-slate-200">
                          <Plus size={20} />
                        </button>
                      </div>
                    </AccordionItem>

                    <AccordionItem id="message" title="First Message" icon={MessageSquare}>
                      <label className="text-xs font-semibold text-slate-700 block mb-2">First message:</label>
                      <textarea value={welcomeMsg} onChange={(e) => setWelcomeMsg(e.target.value)} rows={5}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm leading-relaxed text-slate-700 outline-none focus:border-slate-400 resize-none" />
                      <label className="text-xs font-semibold text-slate-700 block mt-4 mb-2">Display name:</label>
                      <input type="text" value={botName} onChange={(e) => setBotName(e.target.value)}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-slate-400 text-sm font-semibold" />
                    </AccordionItem>

                    <AccordionItem id="forms" title="Forms Customization" icon={Layout}>
                      <p className="text-xs text-slate-500 mb-4 font-medium">Select fields for the pre-chat form.</p>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-sm font-medium text-slate-800">Collect Email</span>
                          <input type="checkbox" checked={showEmailField} onChange={() => setShowEmailField(!showEmailField)} className="w-5 h-5 accent-slate-900 cursor-pointer" />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                          <span className="text-sm font-medium text-slate-800">Collect Name</span>
                          <input type="checkbox" checked={showNameField} onChange={() => setShowNameField(!showNameField)} className="w-5 h-5 accent-slate-900 cursor-pointer" />
                        </div>
                      </div>
                    </AccordionItem>

                    <AccordionItem id="color" title="Color" icon={Pipette}>
                      <div className="flex items-center gap-4">
                        <input type="color" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)}
                          className="h-14 w-20 rounded-xl cursor-pointer border-none p-0 bg-transparent" />
                        <input type="text" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)}
                          className="flex-1 p-4 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm outline-none" />
                      </div>
                    </AccordionItem>
                  </div>

                  <button onClick={handleSaveConfig} disabled={isSavingConfig}
                    className="w-full mt-10 bg-slate-950 text-white py-5 rounded-2xl font-bold hover:bg-black transition-all shadow-xl shadow-slate-200 flex items-center justify-center gap-2 disabled:opacity-70">
                    {isSavingConfig ? <><Loader2 size={18} className="animate-spin" /> Saving...</> :
                     configSaved ? <><CheckCircle2 size={18} className="text-[#C9FA62]" /> Saved!</> :
                     'Set as Default'}
                  </button>
                </div>
              </div>

              {/* Live Preview */}
              <div className="flex-1 flex items-end justify-end p-10">
                <div className="w-full max-w-[380px] bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
                  <div style={{ backgroundColor: primaryColor }} className="p-6 text-white flex justify-between items-center transition-all duration-300">
                    <div className="flex items-center gap-3">
                      <img src={selectedAvatar} alt="Bot Avatar" className="w-10 h-10 rounded-full object-cover border-2 border-white/40" />
                      <div>
                        <h4 className="font-bold leading-tight">{botName}</h4>
                        <span className="text-[10px] opacity-75 font-medium">Ready to assist you today?</span>
                      </div>
                    </div>
                    <X size={20} className="opacity-40" />
                  </div>
                  <div className="h-[280px] p-6 bg-slate-50/60 flex flex-col gap-5 overflow-y-auto">
                    <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm text-sm text-slate-800 leading-relaxed border border-slate-100">
                      {welcomeMsg}
                    </div>
                    <div className="space-y-4">
                      {showNameField && (
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Your Name</label>
                          <input type="text" placeholder="John Doe" className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none" />
                        </div>
                      )}
                      {showEmailField && (
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Your Email</label>
                          <input type="email" placeholder="john@example.com" className="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none" />
                        </div>
                      )}
                      <button style={{ backgroundColor: primaryColor }} className="w-full py-3.5 text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2">
                        Let's chat! <Send size={16} />
                      </button>
                    </div>
                  </div>
                  <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
                    <div className="flex-1 bg-slate-100 px-4 py-2 rounded-full text-sm text-slate-400">Type a message...</div>
                    <div style={{ backgroundColor: primaryColor }} className="w-10 h-10 rounded-full flex items-center justify-center text-white shadow-md">
                      <ArrowRight size={18} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: DEPLOY */}
        {currentStep === 3 && (
          <div className="w-full max-w-4xl space-y-12 text-center flex-1 flex flex-col items-center justify-center">
            <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Installation</h1>
            <p className="text-lg text-slate-600 max-w-xl mx-auto leading-relaxed">
              Copy this script and paste it before the closing <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-bold">&lt;/body&gt;</code> tag of your website.
            </p>
            <div className="bg-white p-10 rounded-[2rem] border border-slate-100 shadow-xl relative w-full text-left font-mono text-sm leading-relaxed">
              <div className="absolute top-4 right-4 flex items-center gap-2 text-xs bg-slate-100 px-3 py-1.5 rounded-full text-slate-500 font-sans">
                {copySuccess ? <CheckCircle2 size={16} className="text-green-500" /> : <DatabaseZap size={16} />}
                data-bot-id=&quot;{widgetApiKey || (isGeneratingApiKey ? 'Generating...' : 'Not ready')}&quot;
              </div>
              <pre className="text-slate-600 p-8 pt-10 bg-slate-50 border border-slate-200 rounded-2xl overflow-x-auto">
                {`<script\n  src="${typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com'}/embed.js"\n  data-bot-id="${widgetApiKey || 'YOUR_WIDGET_API_KEY_HERE'}"\n  data-base-url="${typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com'}"\n  defer\n></script>`}
              </pre>
              <button
                onClick={copyCode}
                disabled={!widgetApiKey || isGeneratingApiKey}
                className="mt-6 w-full flex items-center justify-center gap-2 px-8 py-3.5 bg-slate-950 text-white font-bold rounded-xl hover:bg-black transition-all disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {copySuccess ? 'Copied to Clipboard!' : isGeneratingApiKey ? 'Generating key...' : 'Copy Script'}
                {!copySuccess && <Copy size={18} />}
              </button>
            </div>
            <Link href="/admin/chatbots" className="text-indigo-600 font-bold hover:underline flex items-center gap-1">
              View your chatbots <ArrowRight size={16} />
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}
